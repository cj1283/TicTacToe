import os
import time
import platform
import pygame
from pygame import mixer
from pip._vendor.distlib.compat import *

plt = platform.system()

if plt == "Windows":
    os.system('cls')
    # do x y z
elif plt == "Linux":
    os.system('clear')
    # do x y z
elif plt == "Darwin":
    os.system('clear')
    # do x y z

# board array
board = ["", " ", " ", " ", " ", " ", " ", " ", " ", " "]

# Winning Animation Frames
o_filenames = ["O_1.txt", "O_2.txt"]
x_filenames = ["X_1.txt", "X_2.txt"]

# Displays Winner Animation
def animator(o_filenames, delay=1.0, repeat=10):
    frames = []
    for name in o_filenames:
        with open(name, "r") as f:
            frames.append(f.readlines())
    for i in range(repeat):
        for frame in frames:
            print("".join(frame))
            time.sleep(delay)
            os.system('clear')


# Board Colors
class bcolors:
    BLUE = '\033[1;94m'
    GREEN = '\033[1;92m'
    RED = "\033[1;31m"
    CYAN = "\033[1;36m"
    RESET = "\033[0;0m"


xWins = 0
oWins = 0


# Check Wins
def checkOscore():
    if oWins == 3:
        animator(o_filenames, delay=.2, repeat=10)
        return True


def checkXscore():
    if xWins == 3:
        animator(x_filenames, delay=.2, repeat=10)
        return True


# Print game title and instructions
def print_header():
    header = """
  $$$$$$$\ $$$$$$\   $$$$\   $$$$$$\  $$$$$\    $$$$\     /$$$$$$$ /$$$$  /$$$$$$$   
  \__$  _| \_$  _| $  __$$\  \__$  _| $  __$\ $  __$$\   |__  $__//$__  $| $_____/ 
     $ |     $ |  $  /  \__|    $ |   $ /  $ |$ /  \__|     | $  | $  \ $| $              
     $ |     $ |  $ |           $ |   $$$$$$ |$ |           | $  | $  | $| $$$$         
     $ |     $ |  $ |      |$$| $ |   $  __$ |$ |      |$$| | $  | $  | $| $__/        
     $ |     $ |  $ |  $$\      $ |   $ |  $ |$ |  $$\      | $  | $  | $| $                
     $ |   $$$$$\ \$$$$$  |     $ |   $ |  $ |\$$$$$  |     | $  | $$$$$/| $$$$$$$    
     \_|   \_____| \_____/      \_|   \_|  \_| \______/     |_/   \____/ | ______/

        Play Tic-Tac-Toe! You need to get 3 in a row. Your moves must be 
     from 1 to 9 as shown in the board. Best of five rounds wins! Good Luck!

  """
    header = header.replace('$', bcolors.CYAN + '$' + bcolors.RESET)
    print(header)
    return header


# print_board function
def print_board():
    bcolors.RESET
    pBoard = ("           Score Board           Playing Board         Board Choices  \n"
              + "                                   " + board[1] + " | " + board[2] + " | " + board[
                  3] + "             1 | 2 | 3 \n"
              # print "     |     |     |     "
              + "           X - Wins: " + str(xWins) + "            ---|---|---   " + "        -----------\n"
              # print "     |     |     |     "
              + "                                   " + board[4] + " | " + board[5] + " | " + board[
                  6] + "             4 | 5 | 6 \n"
              # print "     |     |     |     "
              + "           O - Wins: " + str(oWins) + "            ---|---|---   " + "        -----------\n"
              # print "     |     |     |     "
              + "                                   " + board[7] + " | " + board[8] + " | " + board[
                  9] + "             7 | 8 | 9 \n"
              # print "     |     |     |     "
              + "\n")
    pBoard = pBoard.replace('X', bcolors.RED + 'X' + bcolors.RESET).replace('Y',
                                                                            bcolors.BLUE + 'Y' + bcolors.RESET).replace(
        'O', bcolors.GREEN + 'O' + bcolors.RESET)
    print(pBoard)
    return pBoard


# Check if player passed to function has won
def is_winner(board, player):
    if (board[1] == player and board[2] == player and board[3] == player) or \
            (board[4] == player and board[5] == player and board[6] == player) or \
            (board[7] == player and board[8] == player and board[9] == player) or \
            (board[1] == player and board[4] == player and board[7] == player) or \
            (board[2] == player and board[5] == player and board[8] == player) or \
            (board[3] == player and board[6] == player and board[9] == player) or \
            (board[1] == player and board[5] == player and board[9] == player) or \
            (board[7] == player and board[5] == player and board[3] == player):
        win_sound = mixer.Sound('OOT_Secret.wav')
        win_sound.play()
        return True
    else:
        return False


# Check if board is full
def is_board_full(board):
    if " " in board:
        return False
    else:
        return True


def RepresentsInt(s):
    try:
        int(s)
        return True
    except ValueError:
        print("Try again! Enter a number 1-9 only!\n")
        return False


game = 1

# Main program
pygame.init()
mixer.music.load('zelda_04.wav')
mixer.music.play(-1)

while game < 6:
    os.system("clear")
    print_header()
    print_board()
    move = False

    while not move:
        # Get Player X Input
        ok = False
        choice = -1
        while not ok:
            choice = raw_input(bcolors.RESET + "Please choose an empty space for X. ")
            if RepresentsInt(choice):
                choice = int(choice)
                if 10 > choice > 0:
                    ok = True
                else:
                    print("Try again! Enter a number 1-9 only!\n")
                    ok = False
            else:
                error_sound = mixer.Sound('OOT_Error.wav')
                error_sound.play()
                ok = False

        # Check to see if the space is empty first
        if board[choice] == " ":
            board[choice] = "X"
            board_sound = mixer.Sound('OOT_MasterSword_Pedestal_Clank.wav')
            board_sound.play()
            move = True
        else:
            error_sound = mixer.Sound('OOT_Error.wav')
            error_sound.play()
            print("Sorry, that space is not empty!")
            time.sleep(1)

    # Check for X win
    if is_winner(board, "X"):
        os.system("clear")
        print_header()
        print_board()
        print("X wins round " + str(game) + "!")
        time.sleep(1)
        game += 1
        # reset board array
        xWins += 1
        board = ["", " ", " ", " ", " ", " ", " ", " ", " ", " "]

    if checkOscore():
        print("Congrats, Y wins!")
        break

    if checkXscore():
        print("Congrats, X wins!")
        break
    os.system("clear")
    print_header()
    print_board()

    # Check for a tie (is the board full)
    # If the board is full, do something
    if is_board_full(board):
        print("Tie!")
        # reset board array
        board = ["", " ", " ", " ", " ", " ", " ", " ", " ", " "]

    move = False

    while not move:
        # Get Player O Input
        ok = False
        while not ok:
            choice = raw_input(bcolors.RESET + "Please choose an empty space for O. ")
            if RepresentsInt(choice):
                choice = int(choice)
                if 10 > choice > 0:
                    ok = True
                else:
                    print("Try again! Enter a number 1-9 only!\n")
                    ok = False
            else:
                error_sound = mixer.Sound('OOT_Error.wav')
                error_sound.play()
                ok = False

        # Check to see if the space is empty first
        if board[choice] == " ":
            board[choice] = "O"
            board_sound = mixer.Sound('OOT_MasterSword_Pedestal_Clank.wav')
            board_sound.play()
            move = True
        else:
            error_sound = mixer.Sound('OOT_Error.wav')
            error_sound.play()
            print("Sorry, that space is not empty!")
            time.sleep(1)

    # Check for O win
    if is_winner(board, "O"):
        os.system("clear")
        print_header()
        print_board()
        print("O wins round " + str(game) + "!")
        time.sleep(1)
        game += 1
        # rest board array
        oWins += 1
        board = ["", " ", " ", " ", " ", " ", " ", " ", " ", " "]

    if checkOscore():
        print("Congrats, O wins!")
        break

    if checkXscore():
        print("Congrats, X wins!")
        break

    # Check for a tie (is the board full)
    # If the board is full, do something
    if is_board_full(board):
        print("Tie!")
        # reset board array
        board = ["", " ", " ", " ", " ", " ", " ", " ", " ", " "]

    os.system("clear")
    print_header()
    print_board()

    move = False

    # Check for a tie (is the board full)
    # If the board is full, do something
    if is_board_full(board):
        print("Tie!")

    if checkOscore():
        break

    if checkXscore():
        break
